<html>
<div name="form" align="center">
	  <form name="form1" method="POST" action="#" >
	  Send a message
	  To <input type="text" name="user_name"/><br><br>
	  
	  Message  <input type="text" name="message"/><br><br>
	  <input type="submit" name="submit" id="submit" value="Send"/>
	  </form>
	  </div>

</html>
 <?php
 if ( isset( $_POST['submit'] ) ) { 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "xss";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$name=$_POST['user_name'];
$message=$_POST['message'];
$sql = "INSERT INTO Messages (Receiver,Message)
VALUES ('$name','$message')";
if ($conn->query($sql) === TRUE) {
    echo "Message sent";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
}
?> 


