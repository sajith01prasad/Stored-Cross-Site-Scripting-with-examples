<html>
<div name="form" align="center">
	  <form name="form1" method="POST" action="#" >
	  View messages
	  User name <input type="text" name="user_name"/><br><br>
	  
	  <input type="submit" name="submit" id="submit" value="View"/>
	  </form>
	  </div>

</html>
 <?php
 setcookie("localhost","237637276377",false,"/",false);
 if ( isset( $_POST['submit'] ) ) { 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "xss";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$name=$_POST['user_name'];
$sql = "SELECT * FROM Messages WHERE Receiver = '$name'";
$SentMessages = $conn->query($sql);
if ($SentMessages->num_rows > 0) {
    // output data of each row
    while($row = $SentMessages->fetch_assoc()) {
        echo "To: " . $row["Receiver"]. " - Message: " . $row["Message"]. " <br>";
    }
} else {
    echo "0 results";
}
$conn->close();
}
?> 
